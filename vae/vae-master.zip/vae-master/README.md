# vae
a simple vae and cvae from keras

https://kexue.fm/archives/5253

## vae celeba

100 epoch, loss=11585.2258

![64x64_celeba_vae](https://raw.githubusercontent.com/bojone/vae/master/100epoch_celeba.png)


## vae_cluster

https://kexue.fm/archives/5887


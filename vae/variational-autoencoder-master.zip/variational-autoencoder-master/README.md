# variational-autoencoder
generate MNIST using a Variational Autoencoder

![](http://kvfrans.com/content/images/2016/08/mnist.jpg)
![](http://kvfrans.com/content/images/2016/08/vae.jpg)

This is code that goes along with [my post explaining the variational autoencoder.](http://kvfrans.com/variational-autoencoders-explained/)

Based off this [really helpful post](https://jmetzen.github.io/2015-11-27/vae.html)
